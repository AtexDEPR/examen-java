/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.examenjava;

/**
 *
 * @author camper
 */
public class Examenjava {

    public static void main(String[] args) {
        boolean menu = false;
        while (menu) {
           System.out.println("---------------------");
           System.out.println("      MENU           ");
           System.out.println("---------------------");
           System.out.println("1)   CLIENTES        ");
           System.out.println("2)   SERVICIOS       ");
           System.out.println("3)   CONTRATOS       ");
           System.out.println("4)   PROYECTOS       ");
           System.out.println("5)   EMPLEADOS       ");
           System.out.println("6)   SALIR           ");
           System.out.println("---------------------");
           System.out.println("");
           System.out.println("Elija una opcion:");
        }
    };
}
