/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package asignacion;

import java.sql.Date;

/**
 *
 * @author camper
 */
public class asignacion {
    private int id_empleado;
    private int id_proyecto;
    private String horas_trabajadas;
    private Date fecha_asignacion;

    public int getId_empleado() {
        return id_empleado;
    }

    public void setId_empleado(int id_empleado) {
        this.id_empleado = id_empleado;
    }

    public int getId_proyecto() {
        return id_proyecto;
    }

    public void setId_proyecto(int id_proyecto) {
        this.id_proyecto = id_proyecto;
    }

    public String getHoras_trabajadas() {
        return horas_trabajadas;
    }

    public void setHoras_trabajadas(String horas_trabajadas) {
        this.horas_trabajadas = horas_trabajadas;
    }

    public Date getFecha_asignacion() {
        return fecha_asignacion;
    }

    public void setFecha_asignacion(Date fecha_asignacion) {
        this.fecha_asignacion = fecha_asignacion;
    }
}
