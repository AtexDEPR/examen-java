/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ConexionDatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;

/**
 *
 * @author camper
 */
public class ConexionDB {
    public static void main(String[] args) {
        String url = "jdbc:mysql://localhost:3306/soluciones_eficientes";
        String usuario = "campus2023";
        String contraseña = "campus2023";
        Connection conexion = null;
        Statement sentencia = null;
        ResultSet resultado = null;
            try {
// Cargar el driver (opcional en JDBC 4.0+)
                Class.forName("com.mysql.cj.jdbc.Driver");
                System.out.println("Driver JDBC cargado exitosamente.");
// Establecer la conexión
                conexion = DriverManager.getConnection(url, usuario, contraseña);
                System.out.println("Conexión a la base de datos exitosa.");
// Crear una sentencia para ejecutar consultas SQL
                sentencia = conexion.createStatement();
// Ejecutar una consulta
                String sql = "SELECT * FROM mi_tabla";
                resultado = sentencia.executeQuery(sql);
// Procesar los resultados
                    while (resultado.next()) {
                        int id = resultado.getInt("id");
                        String nombre = resultado.getString("nombre");
// ... procesar otros campos
                        System.out.println("ID: " + id + ", Nombre: " + nombre);
                            }
                } catch (ClassNotFoundException e) {
                    System.err.println("Error al cargar el driver JDBC: " + e.getMessage());
                    } catch (SQLException e) {
System.err.println("Error al interactuar con la base de datos: ");
} finally {
// Cerrar los recursos en orden inverso a su creación
try {
if (resultado != null) resultado.close();
if (sentencia != null) sentencia.close();
if (conexion != null) conexion.close();
System.out.println("Recursos de la base de datos cerrados.");
} catch (SQLException e) {
System.err.println("Error al cerrar los recursos: " + e.getMessage());
}
}
}
}
