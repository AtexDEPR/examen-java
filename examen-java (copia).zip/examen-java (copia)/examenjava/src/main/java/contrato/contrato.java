/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package contrato;

import java.sql.Date;

/**
 *
 * @author camper
 */
public class contrato {
    private int id;
    private Date fechainicio;
    private Date fechafin;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getFechainicio() {
        return fechainicio;
    }

    public void setFechainicio(Date fechainicio) {
        this.fechainicio = fechainicio;
    }

    public Date getFechafin() {
        return fechafin;
    }

    public void setFechafin(Date fechafin) {
        this.fechafin = fechafin;
    }

    public int getCostoT() {
        return costoT;
    }

    public void setCostoT(int costoT) {
        this.costoT = costoT;
    }
    private int costoT;
    
    
    
}
