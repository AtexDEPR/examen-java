package com.solucioneseficientes.dao;

import com.solucioneseficientes.conexion.ConexionBD;
import com.solucioneseficientes.modelo.Proyecto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ProyectoDAO {
    
    public boolean registrarProyecto(Proyecto proyecto) {
        String sql = "INSERT INTO Proyecto (ID_Cliente, Nombre, FechaInicio, FechaFin, Estado) VALUES (?, ?, ?, ?, ?)";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, proyecto.getIdCliente());
            stmt.setString(2, proyecto.getNombre());
            stmt.setDate(3, Date.valueOf(proyecto.getFechaInicio()));
            
            if (proyecto.getFechaFin() != null) {
                stmt.setDate(4, Date.valueOf(proyecto.getFechaFin()));
            } else {
                stmt.setNull(4, java.sql.Types.DATE);
            }
            
            stmt.setString(5, proyecto.getEstado());
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar proyecto: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public List<Proyecto> listarProyectos() {
        List<Proyecto> proyectos = new ArrayList<>();
        String sql = "SELECT * FROM Proyecto";
        Connection conexion = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.createStatement();
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Proyecto proyecto = new Proyecto();
                proyecto.setId(rs.getInt("ID"));
                proyecto.setIdCliente(rs.getInt("ID_Cliente"));
                proyecto.setNombre(rs.getString("Nombre"));
                proyecto.setFechaInicio(rs.getDate("FechaInicio").toLocalDate());
                
                Date fechaFin = rs.getDate("FechaFin");
                if (fechaFin != null) {
                    proyecto.setFechaFin(fechaFin.toLocalDate());
                }
                
                proyecto.setEstado(rs.getString("Estado"));
                
                proyectos.add(proyecto);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al listar proyectos: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return proyectos;
    }
    
    public Proyecto buscarProyectoPorId(int id) {
        Proyecto proyecto = null;
        String sql = "SELECT * FROM Proyecto WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                proyecto = new Proyecto();
                proyecto.setId(rs.getInt("ID"));
                proyecto.setIdCliente(rs.getInt("ID_Cliente"));
                proyecto.setNombre(rs.getString("Nombre"));
                proyecto.setFechaInicio(rs.getDate("FechaInicio").toLocalDate());
                
                Date fechaFin = rs.getDate("FechaFin");
                if (fechaFin != null) {
                    proyecto.setFechaFin(fechaFin.toLocalDate());
                }
                
                proyecto.setEstado(rs.getString("Estado"));
            }
            
        } catch (SQLException e) {
            System.err.println("Error al buscar proyecto: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return proyecto;
    }
    
    public List<Proyecto> consultarProyectosActivos() {
        List<Proyecto> proyectos = new ArrayList<>();
        String sql = "SELECT * FROM Proyecto WHERE Estado = 'En curso'";
        Connection conexion = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.createStatement();
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Proyecto proyecto = new Proyecto();
                proyecto.setId(rs.getInt("ID"));
                proyecto.setIdCliente(rs.getInt("ID_Cliente"));
                proyecto.setNombre(rs.getString("Nombre"));
                proyecto.setFechaInicio(rs.getDate("FechaInicio").toLocalDate());
                
                Date fechaFin = rs.getDate("FechaFin");
                if (fechaFin != null) {
                    proyecto.setFechaFin(fechaFin.toLocalDate());
                }
                
                proyecto.setEstado(rs.getString("Estado"));
                
                proyectos.add(proyecto);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al consultar proyectos activos: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return proyectos;
    }
    
    public List<Proyecto> consultarProyectosPorCliente(int idCliente) {
        List<Proyecto> proyectos = new ArrayList<>();
        String sql = "SELECT * FROM Proyecto WHERE ID_Cliente = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, idCliente);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Proyecto proyecto = new Proyecto();
                proyecto.setId(rs.getInt("ID"));
                proyecto.setIdCliente(rs.getInt("ID_Cliente"));
                proyecto.setNombre(rs.getString("Nombre"));
                proyecto.setFechaInicio(rs.getDate("FechaInicio").toLocalDate());
                
                Date fechaFin = rs.getDate("FechaFin");
                if (fechaFin != null) {
                    proyecto.setFechaFin(fechaFin.toLocalDate());
                }
                
                proyecto.setEstado(rs.getString("Estado"));
                
                proyectos.add(proyecto);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al consultar proyectos por cliente: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return proyectos;
    }
    
    public boolean actualizarProyecto(Proyecto proyecto) {
        String sql = "UPDATE Proyecto SET ID_Cliente = ?, Nombre = ?, FechaInicio = ?, FechaFin = ?, Estado = ? WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, proyecto.getIdCliente());
            stmt.setString(2, proyecto.getNombre());
            stmt.setDate(3, Date.valueOf(proyecto.getFechaInicio()));
            
            if (proyecto.getFechaFin() != null) {
                stmt.setDate(4, Date.valueOf(proyecto.getFechaFin()));
            } else {
                stmt.setNull(4, java.sql.Types.DATE);
            }
            
            stmt.setString(5, proyecto.getEstado());
            stmt.setInt(6, proyecto.getId());
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar proyecto: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public boolean completarProyecto(int id) {
        String sql = "UPDATE Proyecto SET Estado = 'Completado', FechaFin = ? WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setDate(1, Date.valueOf(LocalDate.now()));
            stmt.setInt(2, id);
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al completar proyecto: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
}