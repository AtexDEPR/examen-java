package com.solucioneseficientes.dao;

import com.solucioneseficientes.conexion.ConexionBD;
import com.solucioneseficientes.modelo.Empleado;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class EmpleadoDAO {
    
    public boolean registrarEmpleado(Empleado empleado) {
        String sql = "INSERT INTO Empleado (Nombre, Cargo, Salario, Especialidad, ID_Proyecto) VALUES (?, ?, ?, ?, ?)";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setString(1, empleado.getNombre());
            stmt.setString(2, empleado.getCargo());
            stmt.setDouble(3, empleado.getSalario());
            stmt.setString(4, empleado.getEspecialidad());
            
            if (empleado.getIdProyecto() != null) {
                stmt.setInt(5, empleado.getIdProyecto());
            } else {
                stmt.setNull(5, java.sql.Types.INTEGER);
            }
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar empleado: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public List<Empleado> listarEmpleados() {
        List<Empleado> empleados = new ArrayList<>();
        String sql = "SELECT * FROM Empleado";
        Connection conexion = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.createStatement();
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Empleado empleado = new Empleado();
                empleado.setId(rs.getInt("ID"));
                empleado.setNombre(rs.getString("Nombre"));
                empleado.setCargo(rs.getString("Cargo"));
                empleado.setSalario(rs.getDouble("Salario"));
                empleado.setEspecialidad(rs.getString("Especialidad"));
                
                int idProyecto = rs.getInt("ID_Proyecto");
                if (!rs.wasNull()) {
                    empleado.setIdProyecto(idProyecto);
                }
                
                empleados.add(empleado);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al listar empleados: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return empleados;
    }
    
    public Empleado buscarEmpleadoPorId(int id) {
        Empleado empleado = null;
        String sql = "SELECT * FROM Empleado WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                empleado = new Empleado();
                empleado.setId(rs.getInt("ID"));
                empleado.setNombre(rs.getString("Nombre"));
                empleado.setCargo(rs.getString("Cargo"));
                empleado.setSalario(rs.getDouble("Salario"));
                empleado.setEspecialidad(rs.getString("Especialidad"));
                
                int idProyecto = rs.getInt("ID_Proyecto");
                if (!rs.wasNull()) {
                    empleado.setIdProyecto(idProyecto);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("Error al buscar empleado: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return empleado;
    }
    
    public List<Empleado> consultarEmpleadosPorProyecto(int idProyecto) {
        List<Empleado> empleados = new ArrayList<>();
        String sql = "SELECT e.* FROM Empleado e " +
                     "JOIN Asignacion a ON e.ID = a.ID_Empleado " +
                     "WHERE a.ID_Proyecto = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, idProyecto);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Empleado empleado = new Empleado();
                empleado.setId(rs.getInt("ID"));
                empleado.setNombre(rs.getString("Nombre"));
                empleado.setCargo(rs.getString("Cargo"));
                empleado.setSalario(rs.getDouble("Salario"));
                empleado.setEspecialidad(rs.getString("Especialidad"));
                
                int idProy = rs.getInt("ID_Proyecto");
                if (!rs.wasNull()) {
                    empleado.setIdProyecto(idProy);
                }
                
                empleados.add(empleado);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al consultar empleados por proyecto: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return empleados;
    }
    
    public boolean asignarEmpleadoAProyecto(int idEmpleado, int idProyecto) {
        String sql = "UPDATE Empleado SET ID_Proyecto = ? WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, idProyecto);
            stmt.setInt(2, idEmpleado);
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al asignar empleado a proyecto: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public boolean actualizarEmpleado(Empleado empleado) {
        String sql = "UPDATE Empleado SET Nombre = ?, Cargo = ?, Salario = ?, Especialidad = ?, ID_Proyecto = ? WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setString(1, empleado.getNombre());
            stmt.setString(2, empleado.getCargo());
            stmt.setDouble(3, empleado.getSalario());
            stmt.setString(4, empleado.getEspecialidad());
            
            if (empleado.getIdProyecto() != null) {
                stmt.setInt(5, empleado.getIdProyecto());
            } else {
                stmt.setNull(5, java.sql.Types.INTEGER);
            }
            
            stmt.setInt(6, empleado.getId());
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar empleado: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public List<Empleado> listarEmpleadosConMasHorasTrabajadas(int limite) {
        List<Empleado> empleados = new ArrayList<>();
        String sql = "SELECT e.*, SUM(a.HorasTrabajadas) as TotalHoras " +
                     "FROM Empleado e " +
                     "JOIN Asignacion a ON e.ID = a.ID_Empleado " +
                     "GROUP BY e.ID " +
                     "ORDER BY TotalHoras DESC " +
                     "LIMIT ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, limite);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Empleado empleado = new Empleado();
                empleado.setId(rs.getInt("ID"));
                empleado.setNombre(rs.getString("Nombre"));
                empleado.setCargo(rs.getString("Cargo"));
                empleado.setSalario(rs.getDouble("Salario"));
                empleado.setEspecialidad(rs.getString("Especialidad"));
                
                int idProyecto = rs.getInt("ID_Proyecto");
                if (!rs.wasNull()) {
                    empleado.setIdProyecto(idProyecto);
                }
                
                empleados.add(empleado);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al listar empleados con más horas: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return empleados;
    }
}