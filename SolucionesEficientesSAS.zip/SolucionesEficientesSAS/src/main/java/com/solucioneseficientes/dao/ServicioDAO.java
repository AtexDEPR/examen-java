package com.solucioneseficientes.dao;

import com.solucioneseficientes.conexion.ConexionBD;
import com.solucioneseficientes.modelo.Servicio;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ServicioDAO {
    
    public boolean registrarServicio(Servicio servicio) {
        String sql = "INSERT INTO Servicio (Nombre, Descripcion, PrecioPorHora, Categoria) VALUES (?, ?, ?, ?)";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setString(1, servicio.getNombre());
            stmt.setString(2, servicio.getDescripcion());
            stmt.setDouble(3, servicio.getPrecioPorHora());
            stmt.setString(4, servicio.getCategoria());
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar servicio: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public List<Servicio> listarServicios() {
        List<Servicio> servicios = new ArrayList<>();
        String sql = "SELECT * FROM Servicio";
        Connection conexion = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.createStatement();
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Servicio servicio = new Servicio();
                servicio.setId(rs.getInt("ID"));
                servicio.setNombre(rs.getString("Nombre"));
                servicio.setDescripcion(rs.getString("Descripcion"));
                servicio.setPrecioPorHora(rs.getDouble("PrecioPorHora"));
                servicio.setCategoria(rs.getString("Categoria"));
                
                servicios.add(servicio);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al listar servicios: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return servicios;
    }
    
    public Servicio buscarServicioPorId(int id) {
        Servicio servicio = null;
        String sql = "SELECT * FROM Servicio WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                servicio = new Servicio();
                servicio.setId(rs.getInt("ID"));
                servicio.setNombre(rs.getString("Nombre"));
                servicio.setDescripcion(rs.getString("Descripcion"));
                servicio.setPrecioPorHora(rs.getDouble("PrecioPorHora"));
                servicio.setCategoria(rs.getString("Categoria"));
            }
            
        } catch (SQLException e) {
            System.err.println("Error al buscar servicio: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return servicio;
    }
    
    public List<Servicio> consultarServiciosPorCategoria(String categoria) {
        List<Servicio> servicios = new ArrayList<>();
        String sql = "SELECT * FROM Servicio WHERE Categoria = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setString(1, categoria);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Servicio servicio = new Servicio();
                servicio.setId(rs.getInt("ID"));
                servicio.setNombre(rs.getString("Nombre"));
                servicio.setDescripcion(rs.getString("Descripcion"));
                servicio.setPrecioPorHora(rs.getDouble("PrecioPorHora"));
                servicio.setCategoria(rs.getString("Categoria"));
                
                servicios.add(servicio);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al consultar servicios por categoría: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return servicios;
    }
    
    public boolean actualizarServicio(Servicio servicio) {
        String sql = "UPDATE Servicio SET Nombre = ?, Descripcion = ?, PrecioPorHora = ?, Categoria = ? WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setString(1, servicio.getNombre());
            stmt.setString(2, servicio.getDescripcion());
            stmt.setDouble(3, servicio.getPrecioPorHora());
            stmt.setString(4, servicio.getCategoria());
            stmt.setInt(5, servicio.getId());
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar servicio: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public boolean eliminarServicio(int id) {
        String sql = "DELETE FROM Servicio WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, id);
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al eliminar servicio: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public List<Servicio> listarServiciosMasContratados(int limite) {
        List<Servicio> servicios = new ArrayList<>();
        String sql = "SELECT s.*, COUNT(c.ID) as NumContratos " +
                     "FROM Servicio s " +
                     "JOIN Contrato c ON s.ID = c.ID_Servicio " +
                     "GROUP BY s.ID " +
                     "ORDER BY NumContratos DESC " +
                     "LIMIT ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, limite);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Servicio servicio = new Servicio();
                servicio.setId(rs.getInt("ID"));
                servicio.setNombre(rs.getString("Nombre"));
                servicio.setDescripcion(rs.getString("Descripcion"));
                servicio.setPrecioPorHora(rs.getDouble("PrecioPorHora"));
                servicio.setCategoria(rs.getString("Categoria"));
                
                servicios.add(servicio);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al listar servicios más contratados: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return servicios;
    }
}