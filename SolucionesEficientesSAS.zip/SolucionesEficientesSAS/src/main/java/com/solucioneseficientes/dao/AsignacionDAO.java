package com.solucioneseficientes.dao;

import com.solucioneseficientes.conexion.ConexionBD;
import com.solucioneseficientes.modelo.Asignacion;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class AsignacionDAO {
    
    public boolean registrarAsignacion(Asignacion asignacion) {
        String sql = "INSERT INTO Asignacion (ID_Empleado, ID_Proyecto, HorasTrabajadas, FechaAsignacion) VALUES (?, ?, ?, ?)";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, asignacion.getIdEmpleado());
            stmt.setInt(2, asignacion.getIdProyecto());
            stmt.setDouble(3, asignacion.getHorasTrabajadas());
            stmt.setDate(4, Date.valueOf(asignacion.getFechaAsignacion()));
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar asignación: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public List<Asignacion> listarAsignacionesPorProyecto(int idProyecto) {
        List<Asignacion> asignaciones = new ArrayList<>();
        String sql = "SELECT * FROM Asignacion WHERE ID_Proyecto = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, idProyecto);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Asignacion asignacion = new Asignacion();
                asignacion.setIdEmpleado(rs.getInt("ID_Empleado"));
                asignacion.setIdProyecto(rs.getInt("ID_Proyecto"));
                asignacion.setHorasTrabajadas(rs.getDouble("HorasTrabajadas"));
                asignacion.setFechaAsignacion(rs.getDate("FechaAsignacion").toLocalDate());
                
                asignaciones.add(asignacion);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al listar asignaciones por proyecto: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return asignaciones;
    }
    
    public List<Asignacion> listarAsignacionesPorEmpleado(int idEmpleado) {
        List<Asignacion> asignaciones = new ArrayList<>();
        String sql = "SELECT * FROM Asignacion WHERE ID_Empleado = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, idEmpleado);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Asignacion asignacion = new Asignacion();
                asignacion.setIdEmpleado(rs.getInt("ID_Empleado"));
                asignacion.setIdProyecto(rs.getInt("ID_Proyecto"));
                asignacion.setHorasTrabajadas(rs.getDouble("HorasTrabajadas"));
                asignacion.setFechaAsignacion(rs.getDate("FechaAsignacion").toLocalDate());
                
                asignaciones.add(asignacion);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al listar asignaciones por empleado: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return asignaciones;
    }
    
    public Asignacion buscarAsignacion(int idEmpleado, int idProyecto) {
        Asignacion asignacion = null;
        String sql = "SELECT * FROM Asignacion WHERE ID_Empleado = ? AND ID_Proyecto = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, idEmpleado);
            stmt.setInt(2, idProyecto);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                asignacion = new Asignacion();
                asignacion.setIdEmpleado(rs.getInt("ID_Empleado"));
                asignacion.setIdProyecto(rs.getInt("ID_Proyecto"));
                asignacion.setHorasTrabajadas(rs.getDouble("HorasTrabajadas"));
                asignacion.setFechaAsignacion(rs.getDate("FechaAsignacion").toLocalDate());
            }
            
        } catch (SQLException e) {
            System.err.println("Error al buscar asignación: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return asignacion;
    }
    
    public boolean registrarHorasTrabajadas(int idEmpleado, int idProyecto, double horasAdicionales) {
        String sql = "UPDATE Asignacion SET HorasTrabajadas = HorasTrabajadas + ? WHERE ID_Empleado = ? AND ID_Proyecto = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setDouble(1, horasAdicionales);
            stmt.setInt(2, idEmpleado);
            stmt.setInt(3, idProyecto);
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar horas trabajadas: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public boolean eliminarAsignacion(int idEmpleado, int idProyecto) {
        String sql = "DELETE FROM Asignacion WHERE ID_Empleado = ? AND ID_Proyecto = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, idEmpleado);
            stmt.setInt(2, idProyecto);
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al eliminar asignación: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
}