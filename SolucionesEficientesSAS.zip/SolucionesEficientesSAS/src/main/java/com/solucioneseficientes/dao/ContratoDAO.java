package com.solucioneseficientes.dao;

import com.solucioneseficientes.conexion.ConexionBD;
import com.solucioneseficientes.modelo.Cliente;
import com.solucioneseficientes.modelo.Contrato;
import com.solucioneseficientes.modelo.Servicio;
import com.solucioneseficientes.util.ArchivoUtil;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class ContratoDAO {
    
    private ClienteDAO clienteDAO = new ClienteDAO();
    private ServicioDAO servicioDAO = new ServicioDAO();
    
    public boolean registrarContrato(Contrato contrato) {
        String sql = "INSERT INTO Contrato (ID_Cliente, ID_Servicio, FechaInicio, FechaFin, CostoTotal, Estado) VALUES (?, ?, ?, ?, ?, ?)";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, contrato.getIdCliente());
            stmt.setInt(2, contrato.getIdServicio());
            stmt.setDate(3, Date.valueOf(contrato.getFechaInicio()));
            
            if (contrato.getFechaFin() != null) {
                stmt.setDate(4, Date.valueOf(contrato.getFechaFin()));
            } else {
                stmt.setNull(4, java.sql.Types.DATE);
            }
            
            stmt.setDouble(5, contrato.getCostoTotal());
            stmt.setString(6, contrato.getEstado());
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al registrar contrato: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public List<Contrato> listarContratos() {
        List<Contrato> contratos = new ArrayList<>();
        String sql = "SELECT * FROM Contrato";
        Connection conexion = null;
        Statement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.createStatement();
            rs = stmt.executeQuery(sql);
            
            while (rs.next()) {
                Contrato contrato = new Contrato();
                contrato.setId(rs.getInt("ID"));
                contrato.setIdCliente(rs.getInt("ID_Cliente"));
                contrato.setIdServicio(rs.getInt("ID_Servicio"));
                contrato.setFechaInicio(rs.getDate("FechaInicio").toLocalDate());
                
                Date fechaFin = rs.getDate("FechaFin");
                if (fechaFin != null) {
                    contrato.setFechaFin(fechaFin.toLocalDate());
                }
                
                contrato.setCostoTotal(rs.getDouble("CostoTotal"));
                contrato.setEstado(rs.getString("Estado"));
                
                contratos.add(contrato);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al listar contratos: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return contratos;
    }
    
    public Contrato buscarContratoPorId(int id) {
        Contrato contrato = null;
        String sql = "SELECT * FROM Contrato WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, id);
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                contrato = new Contrato();
                contrato.setId(rs.getInt("ID"));
                contrato.setIdCliente(rs.getInt("ID_Cliente"));
                contrato.setIdServicio(rs.getInt("ID_Servicio"));
                contrato.setFechaInicio(rs.getDate("FechaInicio").toLocalDate());
                
                Date fechaFin = rs.getDate("FechaFin");
                if (fechaFin != null) {
                    contrato.setFechaFin(fechaFin.toLocalDate());
                }
                
                contrato.setCostoTotal(rs.getDouble("CostoTotal"));
                contrato.setEstado(rs.getString("Estado"));
            }
            
        } catch (SQLException e) {
            System.err.println("Error al buscar contrato: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return contrato;
    }
    
    public List<Contrato> consultarContratosActivosPorCliente(int idCliente) {
        List<Contrato> contratos = new ArrayList<>();
        String sql = "SELECT * FROM Contrato WHERE ID_Cliente = ? AND Estado = 'Activo'";
        Connection conexion = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, idCliente);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Contrato contrato = new Contrato();
                contrato.setId(rs.getInt("ID"));
                contrato.setIdCliente(rs.getInt("ID_Cliente"));
                contrato.setIdServicio(rs.getInt("ID_Servicio"));
                contrato.setFechaInicio(rs.getDate("FechaInicio").toLocalDate());
                
                Date fechaFin = rs.getDate("FechaFin");
                if (fechaFin != null) {
                    contrato.setFechaFin(fechaFin.toLocalDate());
                }
                
                contrato.setCostoTotal(rs.getDouble("CostoTotal"));
                contrato.setEstado(rs.getString("Estado"));
                
                contratos.add(contrato);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al consultar contratos activos: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return contratos;
    }
    
    public boolean finalizarContrato(int id) {
        String sql = "UPDATE Contrato SET Estado = 'Finalizado', FechaFin = ? WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setDate(1, Date.valueOf(LocalDate.now()));
            stmt.setInt(2, id);
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
            if (exito) {
                Contrato contrato = buscarContratoPorId(id);
                Cliente cliente = clienteDAO.buscarClientePorId(contrato.getIdCliente());
                Servicio servicio = servicioDAO.buscarServicioPorId(contrato.getIdServicio());
                
                ArchivoUtil.guardarResumenContrato(contrato, cliente.getNombre(), servicio.getNombre());
            }
            
        } catch (SQLException e) {
            System.err.println("Error al finalizar contrato: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public boolean actualizarContrato(Contrato contrato) {
        String sql = "UPDATE Contrato SET ID_Cliente = ?, ID_Servicio = ?, FechaInicio = ?, FechaFin = ?, CostoTotal = ?, Estado = ? WHERE ID = ?";
        Connection conexion = null;
        PreparedStatement stmt = null;
        boolean exito = false;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.prepareStatement(sql);
            stmt.setInt(1, contrato.getIdCliente());
            stmt.setInt(2, contrato.getIdServicio());
            stmt.setDate(3, Date.valueOf(contrato.getFechaInicio()));
            
            if (contrato.getFechaFin() != null) {
                stmt.setDate(4, Date.valueOf(contrato.getFechaFin()));
            } else {
                stmt.setNull(4, java.sql.Types.DATE);
            }
            
            stmt.setDouble(5, contrato.getCostoTotal());
            stmt.setString(6, contrato.getEstado());
            stmt.setInt(7, contrato.getId());
            
            int filasAfectadas = stmt.executeUpdate();
            exito = filasAfectadas > 0;
            
        } catch (SQLException e) {
            System.err.println("Error al actualizar contrato: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return exito;
    }
    
    public double calcularIngresosTotales() {
        String sql = "SELECT SUM(CostoTotal) FROM Contrato WHERE Estado = 'Activo'";
        Connection conexion = null;
        Statement stmt = null;
        ResultSet rs = null;
        double ingresos = 0.0;
        
        try {
            conexion = ConexionBD.obtenerConexion();
            stmt = conexion.createStatement();
            rs = stmt.executeQuery(sql);
            
            if (rs.next()) {
                ingresos = rs.getDouble(1);
            }
            
        } catch (SQLException e) {
            System.err.println("Error al calcular ingresos totales: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                ConexionBD.cerrarConexion(conexion);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos: " + e.getMessage());
            }
        }
        
        return ingresos;
    }
}