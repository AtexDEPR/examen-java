package com.solucioneseficientes;

import com.solucioneseficientes.dao.*;
import com.solucioneseficientes.modelo.*;
import com.solucioneseficientes.util.ArchivoUtil;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

public class Main {
    
    private static final Scanner scanner = new Scanner(System.in);
    private static final ClienteDAO clienteDAO = new ClienteDAO();
    private static final ServicioDAO servicioDAO = new ServicioDAO();
    private static final ContratoDAO contratoDAO = new ContratoDAO();
    private static final EmpleadoDAO empleadoDAO = new EmpleadoDAO();
    private static final ProyectoDAO proyectoDAO = new ProyectoDAO();
    private static final AsignacionDAO asignacionDAO = new AsignacionDAO();
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    
    public static void main(String[] args) {
        boolean salir = false;
        
        System.out.println("=================================================");
        System.out.println("   SISTEMA DE GESTIÓN - SOLUCIONES EFICIENTES SAS");
        System.out.println("=================================================");
        
        while (!salir) {
            mostrarMenuPrincipal();
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    gestionClientes();
                    break;
                case 2:
                    gestionServicios();
                    break;
                case 3:
                    gestionContratos();
                    break;
                case 4:
                    gestionProyectos();
                    break;
                case 5:
                    gestionEmpleados();
                    break;
                case 6:
                    generarInformes();
                    break;
                case 0:
                    salir = true;
                    System.out.println("¡Gracias por usar el sistema de Soluciones Eficientes SAS!");
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
        
        scanner.close();
    }
    
    private static void mostrarMenuPrincipal() {
        System.out.println("\n===== MENÚ PRINCIPAL =====");
        System.out.println("1. Gestión de Clientes");
        System.out.println("2. Gestión de Servicios");
        System.out.println("3. Gestión de Contratos");
        System.out.println("4. Gestión de Proyectos");
        System.out.println("5. Gestión de Empleados");
        System.out.println("6. Informes");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }
    
    private static int leerOpcion() {
        try {
            return Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            return -1;
        }
    }
    
    private static void gestionClientes() {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n===== GESTIÓN DE CLIENTES =====");
            System.out.println("1. Registrar nuevo cliente");
            System.out.println("2. Listar todos los clientes");
            System.out.println("3. Buscar cliente por ID");
            System.out.println("4. Listar clientes con contratos activos");
            System.out.println("5. Actualizar cliente");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    registrarCliente();
                    break;
                case 2:
                    listarClientes();
                    break;
                case 3:
                    buscarClientePorId();
                    break;
                case 4:
                    listarClientesConContratosActivos();
                    break;
                case 5:
                    actualizarCliente();
                    break;
                case 0:
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }
    
    private static void registrarCliente() {
        System.out.println("\n===== REGISTRAR NUEVO CLIENTE =====");
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Representante: ");
        String representante = scanner.nextLine();
        
        System.out.print("Correo: ");
        String correo = scanner.nextLine();
        
        System.out.print("Teléfono: ");
        String telefono = scanner.nextLine();
        
        System.out.print("Dirección: ");
        String direccion = scanner.nextLine();
        
        System.out.println("Sector (Tecnologia, Salud, Educacion, Comercio, Manufactura): ");
        String sector = scanner.nextLine();
        
        Cliente cliente = new Cliente(nombre, representante, correo, telefono, direccion, sector);
        
        if (clienteDAO.registrarCliente(cliente)) {
            System.out.println("Cliente registrado exitosamente.");
        } else {
            System.out.println("Error al registrar el cliente.");
        }
        
        esperarEnter();
    }
    
    private static void listarClientes() {
        System.out.println("\n===== LISTA DE CLIENTES =====");
        
        List<Cliente> clientes = clienteDAO.listarClientes();
        
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes registrados.");
        } else {
            clientes.forEach(cliente -> {
                System.out.println("ID: " + cliente.getId());
                System.out.println("Nombre: " + cliente.getNombre());
                System.out.println("Representante: " + cliente.getRepresentante());
                System.out.println("Correo: " + cliente.getCorreo());
                System.out.println("Teléfono: " + cliente.getTelefono());
                System.out.println("Dirección: " + cliente.getDireccion());
                System.out.println("Sector: " + cliente.getSector());
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void buscarClientePorId() {
        System.out.println("\n===== BUSCAR CLIENTE POR ID =====");
        
        System.out.print("Ingrese el ID del cliente: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Cliente cliente = clienteDAO.buscarClientePorId(id);
        
        if (cliente == null) {
            System.out.println("No se encontró un cliente con el ID: " + id);
        } else {
            System.out.println("ID: " + cliente.getId());
            System.out.println("Nombre: " + cliente.getNombre());
            System.out.println("Representante: " + cliente.getRepresentante());
            System.out.println("Correo: " + cliente.getCorreo());
            System.out.println("Teléfono: " + cliente.getTelefono());
            System.out.println("Dirección: " + cliente.getDireccion());
            System.out.println("Sector: " + cliente.getSector());
        }
        
        esperarEnter();
    }
    
    private static void listarClientesConContratosActivos() {
        System.out.println("\n===== CLIENTES CON CONTRATOS ACTIVOS =====");
        
        List<Cliente> clientes = clienteDAO.listarClientesConContratosActivos();
        
        if (clientes.isEmpty()) {
            System.out.println("No hay clientes con contratos activos.");
        } else {
            clientes.forEach(cliente -> {
                System.out.println("ID: " + cliente.getId());
                System.out.println("Nombre: " + cliente.getNombre());
                System.out.println("Representante: " + cliente.getRepresentante());
                System.out.println("Sector: " + cliente.getSector());
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void actualizarCliente() {
        System.out.println("\n===== ACTUALIZAR CLIENTE =====");
        
        System.out.print("Ingrese el ID del cliente a actualizar: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Cliente cliente = clienteDAO.buscarClientePorId(id);
        
        if (cliente == null) {
            System.out.println("No se encontró un cliente con el ID: " + id);
            esperarEnter();
            return;
        }
        
        System.out.println("Datos actuales del cliente:");
        System.out.println("Nombre: " + cliente.getNombre());
        System.out.println("Representante: " + cliente.getRepresentante());
        System.out.println("Correo: " + cliente.getCorreo());
        System.out.println("Teléfono: " + cliente.getTelefono());
        System.out.println("Dirección: " + cliente.getDireccion());
        System.out.println("Sector: " + cliente.getSector());
        
        System.out.println("\nIngrese los nuevos datos (deje en blanco para mantener el valor actual):");
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        if (!nombre.isEmpty()) {
            cliente.setNombre(nombre);
        }
        
        System.out.print("Representante: ");
        String representante = scanner.nextLine();
        if (!representante.isEmpty()) {
            cliente.setRepresentante(representante);
        }
        
        System.out.print("Correo: ");
        String correo = scanner.nextLine();
        if (!correo.isEmpty()) {
            cliente.setCorreo(correo);
        }
        
        System.out.print("Teléfono: ");
        String telefono = scanner.nextLine();
        if (!telefono.isEmpty()) {
            cliente.setTelefono(telefono);
        }
        
        System.out.print("Dirección: ");
        String direccion = scanner.nextLine();
        if (!direccion.isEmpty()) {
            cliente.setDireccion(direccion);
        }
        
        System.out.print("Sector (Tecnologia, Salud, Educacion, Comercio, Manufactura): ");
        String sector = scanner.nextLine();
        if (!sector.isEmpty()) {
            cliente.setSector(sector);
        }
        
        if (clienteDAO.actualizarCliente(cliente)) {
            System.out.println("Cliente actualizado exitosamente.");
        } else {
            System.out.println("Error al actualizar el cliente.");
        }
        
        esperarEnter();
    }
    
    private static void gestionServicios() {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n===== GESTIÓN DE SERVICIOS =====");
            System.out.println("1. Registrar nuevo servicio");
            System.out.println("2. Listar todos los servicios");
            System.out.println("3. Consultar servicios por categoría");
            System.out.println("4. Buscar servicio por ID");
            System.out.println("5. Actualizar servicio");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    registrarServicio();
                    break;
                case 2:
                    listarServicios();
                    break;
                case 3:
                    consultarServiciosPorCategoria();
                    break;
                case 4:
                    buscarServicioPorId();
                    break;
                case 5:
                    actualizarServicio();
                    break;
                case 0:
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }
    
    private static void registrarServicio() {
        System.out.println("\n===== REGISTRAR NUEVO SERVICIO =====");
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        
        System.out.print("Precio por hora (COP): ");
        double precioPorHora = 0;
        try {
            precioPorHora = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Precio no válido. Se establecerá en 0.");
        }
        
        System.out.println("Categoría (TI, Limpieza, Seguridad, Administracion): ");
        String categoria = scanner.nextLine();
        
        Servicio servicio = new Servicio(nombre, descripcion, precioPorHora, categoria);
        
        if (servicioDAO.registrarServicio(servicio)) {
            System.out.println("Servicio registrado exitosamente.");
        } else {
            System.out.println("Error al registrar el servicio.");
        }
        
        esperarEnter();
    }
    
    private static void listarServicios() {
        System.out.println("\n===== LISTA DE SERVICIOS =====");
        
        List<Servicio> servicios = servicioDAO.listarServicios();
        
        if (servicios.isEmpty()) {
            System.out.println("No hay servicios registrados.");
        } else {
            servicios.forEach(servicio -> {
                System.out.println("ID: " + servicio.getId());
                System.out.println("Nombre: " + servicio.getNombre());
                System.out.println("Descripción: " + servicio.getDescripcion());
                System.out.println("Precio por hora: $" + servicio.getPrecioPorHora() + " COP");
                System.out.println("Categoría: " + servicio.getCategoria());
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void consultarServiciosPorCategoria() {
        System.out.println("\n===== CONSULTAR SERVICIOS POR CATEGORÍA =====");
        
        System.out.println("Categorías disponibles: TI, Limpieza, Seguridad, Administracion");
        System.out.print("Ingrese la categoría: ");
        String categoria = scanner.nextLine();
        
        List<Servicio> servicios = servicioDAO.consultarServiciosPorCategoria(categoria);
        
        if (servicios.isEmpty()) {
            System.out.println("No hay servicios registrados en la categoría: " + categoria);
        } else {
            System.out.println("\nServicios en la categoría " + categoria + ":");
            servicios.forEach(servicio -> {
                System.out.println("ID: " + servicio.getId());
                System.out.println("Nombre: " + servicio.getNombre());
                System.out.println("Descripción: " + servicio.getDescripcion());
                System.out.println("Precio por hora: $" + servicio.getPrecioPorHora() + " COP");
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void buscarServicioPorId() {
        System.out.println("\n===== BUSCAR SERVICIO POR ID =====");
        
        System.out.print("Ingrese el ID del servicio: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Servicio servicio = servicioDAO.buscarServicioPorId(id);
        
        if (servicio == null) {
            System.out.println("No se encontró un servicio con el ID: " + id);
        } else {
            System.out.println("ID: " + servicio.getId());
            System.out.println("Nombre: " + servicio.getNombre());
            System.out.println("Descripción: " + servicio.getDescripcion());
            System.out.println("Precio por hora: $" + servicio.getPrecioPorHora() + " COP");
            System.out.println("Categoría: " + servicio.getCategoria());
        }
        
        esperarEnter();
    }
    
    private static void actualizarServicio() {
        System.out.println("\n===== ACTUALIZAR SERVICIO =====");
        
        System.out.print("Ingrese el ID del servicio a actualizar: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Servicio servicio = servicioDAO.buscarServicioPorId(id);
        
        if (servicio == null) {
            System.out.println("No se encontró un servicio con el ID: " + id);
            esperarEnter();
            return;
        }
        
        System.out.println("Datos actuales del servicio:");
        System.out.println("Nombre: " + servicio.getNombre());
        System.out.println("Descripción: " + servicio.getDescripcion());
        System.out.println("Precio por hora: $" + servicio.getPrecioPorHora() + " COP");
        System.out.println("Categoría: " + servicio.getCategoria());
        
        System.out.println("\nIngrese los nuevos datos (deje en blanco para mantener el valor actual):");
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        if (!nombre.isEmpty()) {
            servicio.setNombre(nombre);
        }
        
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        if (!descripcion.isEmpty()) {
            servicio.setDescripcion(descripcion);
        }
        
        System.out.print("Precio por hora (COP): ");
        String precioStr = scanner.nextLine();
        if (!precioStr.isEmpty()) {
            try {
                double precio = Double.parseDouble(precioStr);
                servicio.setPrecioPorHora(precio);
            } catch (NumberFormatException e) {
                System.out.println("Precio no válido. Se mantendrá el valor actual.");
            }
        }
        
        System.out.print("Categoría (TI, Limpieza, Seguridad, Administracion): ");
        String categoria = scanner.nextLine();
        if (!categoria.isEmpty()) {
            servicio.setCategoria(categoria);
        }
        
        if (servicioDAO.actualizarServicio(servicio)) {
            System.out.println("Servicio actualizado exitosamente.");
        } else {
            System.out.println("Error al actualizar el servicio.");
        }
        
        esperarEnter();
    }
    
    private static void gestionContratos() {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n===== GESTIÓN DE CONTRATOS =====");
            System.out.println("1. Registrar nuevo contrato");
            System.out.println("2. Listar todos los contratos");
            System.out.println("3. Consultar contratos activos por cliente");
            System.out.println("4. Finalizar contrato");
            System.out.println("5. Buscar contrato por ID");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    registrarContrato();
                    break;
                case 2:
                    listarContratos();
                    break;
                case 3:
                    consultarContratosActivosPorCliente();
                    break;
                case 4:
                    finalizarContrato();
                    break;
                case 5:
                    buscarContratoPorId();
                    break;
                case 0:
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }
    
    private static void registrarContrato() {
        System.out.println("\n===== REGISTRAR NUEVO CONTRATO =====");
        
        System.out.print("ID del cliente: ");
        int idCliente = leerOpcion();
        
        if (idCliente <= 0) {
            System.out.println("ID de cliente no válido.");
            esperarEnter();
            return;
        }
        
        Cliente cliente = clienteDAO.buscarClientePorId(idCliente);
        if (cliente == null) {
            System.out.println("No existe un cliente con el ID: " + idCliente);
            esperarEnter();
            return;
        }
        
        System.out.print("ID del servicio: ");
        int idServicio = leerOpcion();
        
        if (idServicio <= 0) {
            System.out.println("ID de servicio no válido.");
            esperarEnter();
            return;
        }
        
        Servicio servicio = servicioDAO.buscarServicioPorId(idServicio);
        if (servicio == null) {
            System.out.println("No existe un servicio con el ID: " + idServicio);
            esperarEnter();
            return;
        }
        
        System.out.print("Fecha de inicio (YYYY-MM-DD): ");
        String fechaInicioStr = scanner.nextLine();
        LocalDate fechaInicio;
        
        try {
            fechaInicio = LocalDate.parse(fechaInicioStr, formatter);
        } catch (DateTimeParseException e) {
            System.out.println("Formato de fecha inválido. Se usará la fecha actual.");
            fechaInicio = LocalDate.now();
        }
        
        System.out.print("Fecha de fin (YYYY-MM-DD) - Dejar en blanco si es indefinido: ");
        String fechaFinStr = scanner.nextLine();
        LocalDate fechaFin = null;
        
        if (!fechaFinStr.isEmpty()) {
            try {
                fechaFin = LocalDate.parse(fechaFinStr, formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Formato de fecha inválido. Se dejará como indefinido.");
            }
        }
        
        System.out.print("Costo total del contrato (COP): ");
        double costoTotal = 0;
        try {
            costoTotal = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Costo no válido. Se calculará automáticamente.");
            
            System.out.print("Número de horas contratadas: ");
            try {
                int horas = Integer.parseInt(scanner.nextLine());
                costoTotal = servicio.calcularCostoTotal(horas);
                System.out.println("Costo calculado: $" + costoTotal + " COP");
            } catch (NumberFormatException ex) {
                System.out.println("Número de horas no válido. Se establecerá en 0.");
            }
        }
        
        System.out.println("Estado del contrato (Activo, En espera, Finalizado): ");
        String estado = scanner.nextLine();
        if (estado.isEmpty()) {
            estado = "Activo";
        }
        
        Contrato contrato = new Contrato(idCliente, idServicio, fechaInicio, fechaFin, costoTotal, estado);
        
        if (contratoDAO.registrarContrato(contrato)) {
            System.out.println("Contrato registrado exitosamente.");
        } else {
            System.out.println("Error al registrar el contrato.");
        }
        
        esperarEnter();
    }
    
    private static void listarContratos() {
        System.out.println("\n===== LISTA DE CONTRATOS =====");
        
        List<Contrato> contratos = contratoDAO.listarContratos();
        
        if (contratos.isEmpty()) {
            System.out.println("No hay contratos registrados.");
        } else {
            contratos.forEach(contrato -> {
                System.out.println("ID: " + contrato.getId());
                System.out.println("ID Cliente: " + contrato.getIdCliente());
                System.out.println("ID Servicio: " + contrato.getIdServicio());
                System.out.println("Fecha Inicio: " + contrato.getFechaInicio());
                System.out.println("Fecha Fin: " + (contrato.getFechaFin() != null ? contrato.getFechaFin() : "Indefinido"));
                System.out.println("Costo Total: $" + contrato.getCostoTotal() + " COP");
                System.out.println("Estado: " + contrato.getEstado());
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void consultarContratosActivosPorCliente() {
        System.out.println("\n===== CONSULTAR CONTRATOS ACTIVOS POR CLIENTE =====");
        
        System.out.print("Ingrese el ID del cliente: ");
        int idCliente = leerOpcion();
        
        if (idCliente <= 0) {
            System.out.println("ID de cliente no válido.");
            esperarEnter();
            return;
        }
        
        Cliente cliente = clienteDAO.buscarClientePorId(idCliente);
        if (cliente == null) {
            System.out.println("No existe un cliente con el ID: " + idCliente);
            esperarEnter();
            return;
        }
        
        List<Contrato> contratos = contratoDAO.consultarContratosActivosPorCliente(idCliente);
        
        if (contratos.isEmpty()) {
            System.out.println("El cliente " + cliente.getNombre() + " no tiene contratos activos.");
        } else {
            System.out.println("\nContratos activos del cliente " + cliente.getNombre() + ":");
            contratos.forEach(contrato -> {
                System.out.println("ID: " + contrato.getId());
                System.out.println("ID Servicio: " + contrato.getIdServicio());
                System.out.println("Fecha Inicio: " + contrato.getFechaInicio());
                System.out.println("Fecha Fin: " + (contrato.getFechaFin() != null ? contrato.getFechaFin() : "Indefinido"));
                System.out.println("Costo Total: $" + contrato.getCostoTotal() + " COP");
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void finalizarContrato() {
        System.out.println("\n===== FINALIZAR CONTRATO =====");
        
        System.out.print("Ingrese el ID del contrato a finalizar: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Contrato contrato = contratoDAO.buscarContratoPorId(id);
        
        if (contrato == null) {
            System.out.println("No se encontró un contrato con el ID: " + id);
            esperarEnter();
            return;
        }
        
        if ("Finalizado".equals(contrato.getEstado())) {
            System.out.println("El contrato ya está finalizado.");
            esperarEnter();
            return;
        }
        
        System.out.println("Datos del contrato a finalizar:");
        System.out.println("ID Cliente: " + contrato.getIdCliente());
        System.out.println("ID Servicio: " + contrato.getIdServicio());
        System.out.println("Fecha Inicio: " + contrato.getFechaInicio());
        System.out.println("Costo Total: $" + contrato.getCostoTotal() + " COP");
        System.out.println("Estado actual: " + contrato.getEstado());
        
        System.out.print("¿Está seguro de finalizar este contrato? (S/N): ");
        String confirmacion = scanner.nextLine();
        
        if (confirmacion.equalsIgnoreCase("S")) {
            if (contratoDAO.finalizarContrato(id)) {
                System.out.println("Contrato finalizado exitosamente.");
                System.out.println("Se ha guardado un resumen del contrato en el archivo de contratos finalizados.");
            } else {
                System.out.println("Error al finalizar el contrato.");
            }
        } else {
            System.out.println("Operación cancelada.");
        }
        
        esperarEnter();
    }
    
    private static void buscarContratoPorId() {
        System.out.println("\n===== BUSCAR CONTRATO POR ID =====");
        
        System.out.print("Ingrese el ID del contrato: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Contrato contrato = contratoDAO.buscarContratoPorId(id);
        
        if (contrato == null) {
            System.out.println("No se encontró un contrato con el ID: " + id);
        } else {
            System.out.println("ID: " + contrato.getId());
            System.out.println("ID Cliente: " + contrato.getIdCliente());
            System.out.println("ID Servicio: " + contrato.getIdServicio());
            System.out.println("Fecha Inicio: " + contrato.getFechaInicio());
            System.out.println("Fecha Fin: " + (contrato.getFechaFin() != null ? contrato.getFechaFin() : "Indefinido"));
            System.out.println("Costo Total: $" + contrato.getCostoTotal() + " COP");
            System.out.println("Estado: " + contrato.getEstado());
            System.out.println(contrato.verEstadoContrato());
        }
        
        esperarEnter();
    }
    
    private static void gestionProyectos() {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n===== GESTIÓN DE PROYECTOS =====");
            System.out.println("1. Crear nuevo proyecto");
            System.out.println("2. Listar todos los proyectos");
            System.out.println("3. Consultar proyectos activos");
            System.out.println("4. Asignar empleado a proyecto");
            System.out.println("5. Completar proyecto");
            System.out.println("6. Buscar proyecto por ID");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    crearProyecto();
                    break;
                case 2:
                    listarProyectos();
                    break;
                case 3:
                    consultarProyectosActivos();
                    break;
                case 4:
                    asignarEmpleadoAProyecto();
                    break;
                case 5:
                    completarProyecto();
                    break;
                case 6:
                    buscarProyectoPorId();
                    break;
                case 0:
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }
    
    private static void crearProyecto() {
        System.out.println("\n===== CREAR NUEVO PROYECTO =====");
        
        System.out.print("ID del cliente: ");
        int idCliente = leerOpcion();
        
        if (idCliente <= 0) {
            System.out.println("ID de cliente no válido.");
            esperarEnter();
            return;
        }
        
        Cliente cliente = clienteDAO.buscarClientePorId(idCliente);
        if (cliente == null) {
            System.out.println("No existe un cliente con el ID: " + idCliente);
            esperarEnter();
            return;
        }
        
        System.out.print("Nombre del proyecto: ");
        String nombre = scanner.nextLine();
        
        if (nombre.isEmpty()) {
            System.out.println("El nombre del proyecto no puede estar vacío.");
            esperarEnter();
            return;
        }
        
        System.out.print("Fecha de inicio (YYYY-MM-DD): ");
        String fechaInicioStr = scanner.nextLine();
        LocalDate fechaInicio;
        
        try {
            fechaInicio = LocalDate.parse(fechaInicioStr, formatter);
        } catch (DateTimeParseException e) {
            System.out.println("Formato de fecha inválido. Se usará la fecha actual.");
            fechaInicio = LocalDate.now();
        }
        
        System.out.print("Fecha de fin (YYYY-MM-DD) - Dejar en blanco si es indefinido: ");
        String fechaFinStr = scanner.nextLine();
        LocalDate fechaFin = null;
        
        if (!fechaFinStr.isEmpty()) {
            try {
                fechaFin = LocalDate.parse(fechaFinStr, formatter);
            } catch (DateTimeParseException e) {
                System.out.println("Formato de fecha inválido. Se dejará como indefinido.");
            }
        }
        
        System.out.println("Estado del proyecto (En curso, Completado, Cancelado): ");
        String estado = scanner.nextLine();
        if (estado.isEmpty()) {
            estado = "En curso";
        }
        
        Proyecto proyecto = new Proyecto(idCliente, nombre, fechaInicio, fechaFin, estado);
        
        if (proyectoDAO.registrarProyecto(proyecto)) {
            System.out.println("Proyecto creado exitosamente.");
        } else {
            System.out.println("Error al crear el proyecto.");
        }
        
        esperarEnter();
    }
    
    private static void listarProyectos() {
        System.out.println("\n===== LISTA DE PROYECTOS =====");
        
        List<Proyecto>  {
        System.out.println("\n===== LISTA DE PROYECTOS =====");
        
        List<Proyecto> proyectos = proyectoDAO.listarProyectos();
        
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos registrados.");
        } else {
            proyectos.forEach(proyecto -> {
                System.out.println("ID: " + proyecto.getId());
                System.out.println("ID Cliente: " + proyecto.getIdCliente());
                System.out.println("Nombre: " + proyecto.getNombre());
                System.out.println("Fecha Inicio: " + proyecto.getFechaInicio());
                System.out.println("Fecha Fin: " + (proyecto.getFechaFin() != null ? proyecto.getFechaFin() : "Indefinido"));
                System.out.println("Estado: " + proyecto.getEstado());
                
                long duracion = proyecto.calcularDuracion();
                if (duracion >= 0) {
                    System.out.println("Duración: " + duracion + " días");
                } else {
                    System.out.println("Duración: En curso");
                }
                
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void consultarProyectosActivos() {
        System.out.println("\n===== PROYECTOS ACTIVOS =====");
        
        List<Proyecto> proyectos = proyectoDAO.consultarProyectosActivos();
        
        if (proyectos.isEmpty()) {
            System.out.println("No hay proyectos activos.");
        } else {
            proyectos.forEach(proyecto -> {
                System.out.println("ID: " + proyecto.getId());
                System.out.println("ID Cliente: " + proyecto.getIdCliente());
                System.out.println("Nombre: " + proyecto.getNombre());
                System.out.println("Fecha Inicio: " + proyecto.getFechaInicio());
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void asignarEmpleadoAProyecto() {
        System.out.println("\n===== ASIGNAR EMPLEADO A PROYECTO =====");
        
        System.out.print("ID del empleado: ");
        int idEmpleado = leerOpcion();
        
        if (idEmpleado <= 0) {
            System.out.println("ID de empleado no válido.");
            esperarEnter();
            return;
        }
        
        Empleado empleado = empleadoDAO.buscarEmpleadoPorId(idEmpleado);
        if (empleado == null) {
            System.out.println("No existe un empleado con el ID: " + idEmpleado);
            esperarEnter();
            return;
        }
        
        System.out.print("ID del proyecto: ");
        int idProyecto = leerOpcion();
        
        if (idProyecto <= 0) {
            System.out.println("ID de proyecto no válido.");
            esperarEnter();
            return;
        }
        
        Proyecto proyecto = proyectoDAO.buscarProyectoPorId(idProyecto);
        if (proyecto == null) {
            System.out.println("No existe un proyecto con el ID: " + idProyecto);
            esperarEnter();
            return;
        }
        
        if (!"En curso".equals(proyecto.getEstado())) {
            System.out.println("No se puede asignar un empleado a un proyecto que no está en curso.");
            esperarEnter();
            return;
        }
        
        System.out.print("Horas iniciales asignadas: ");
        double horasIniciales = 0;
        try {
            horasIniciales = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Valor no válido. Se establecerá en 0.");
        }
        
        Asignacion asignacion = new Asignacion(idEmpleado, idProyecto, horasIniciales, LocalDate.now());
        
        if (asignacionDAO.registrarAsignacion(asignacion)) {
            System.out.println("Empleado asignado exitosamente al proyecto.");
            
            empleado.asignarProyecto(idProyecto);
            empleadoDAO.asignarEmpleadoAProyecto(idEmpleado, idProyecto);
        } else {
            System.out.println("Error al asignar el empleado al proyecto.");
        }
        
        esperarEnter();
    }
    
    private static void completarProyecto() {
        System.out.println("\n===== COMPLETAR PROYECTO =====");
        
        System.out.print("Ingrese el ID del proyecto a completar: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Proyecto proyecto = proyectoDAO.buscarProyectoPorId(id);
        
        if (proyecto == null) {
            System.out.println("No se encontró un proyecto con el ID: " + id);
            esperarEnter();
            return;
        }
        
        if (!"En curso".equals(proyecto.getEstado())) {
            System.out.println("El proyecto no está en curso. Estado actual: " + proyecto.getEstado());
            esperarEnter();
            return;
        }
        
        System.out.println("Datos del proyecto a completar:");
        System.out.println("ID: " + proyecto.getId());
        System.out.println("Nombre: " + proyecto.getNombre());
        System.out.println("ID Cliente: " + proyecto.getIdCliente());
        System.out.println("Fecha Inicio: " + proyecto.getFechaInicio());
        
        System.out.print("¿Está seguro de marcar este proyecto como completado? (S/N): ");
        String confirmacion = scanner.nextLine();
        
        if (confirmacion.equalsIgnoreCase("S")) {
            if (proyectoDAO.completarProyecto(id)) {
                System.out.println("Proyecto marcado como completado exitosamente.");
            } else {
                System.out.println("Error al completar el proyecto.");
            }
        } else {
            System.out.println("Operación cancelada.");
        }
        
        esperarEnter();
    }
    
    private static void buscarProyectoPorId() {
        System.out.println("\n===== BUSCAR PROYECTO POR ID =====");
        
        System.out.print("Ingrese el ID del proyecto: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Proyecto proyecto = proyectoDAO.buscarProyectoPorId(id);
        
        if (proyecto == null) {
            System.out.println("No se encontró un proyecto con el ID: " + id);
        } else {
            System.out.println("ID: " + proyecto.getId());
            System.out.println("ID Cliente: " + proyecto.getIdCliente());
            System.out.println("Nombre: " + proyecto.getNombre());
            System.out.println("Fecha Inicio: " + proyecto.getFechaInicio());
            System.out.println("Fecha Fin: " + (proyecto.getFechaFin() != null ? proyecto.getFechaFin() : "Indefinido"));
            System.out.println("Estado: " + proyecto.getEstado());
            
            long duracion = proyecto.calcularDuracion();
            if (duracion >= 0) {
                System.out.println("Duración: " + duracion + " días");
            } else {
                System.out.println("Duración: En curso");
            }
            
            List<Empleado> empleados = empleadoDAO.consultarEmpleadosPorProyecto(id);
            if (empleados.isEmpty()) {
                System.out.println("No hay empleados asignados a este proyecto.");
            } else {
                System.out.println("\nEmpleados asignados:");
                empleados.forEach(empleado -> {
                    System.out.println("- " + empleado.getNombre() + " (" + empleado.getCargo() + ")");
                });
            }
        }
        
        esperarEnter();
    }
    
    private static void gestionEmpleados() {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n===== GESTIÓN DE EMPLEADOS =====");
            System.out.println("1. Registrar nuevo empleado");
            System.out.println("2. Listar todos los empleados");
            System.out.println("3. Buscar empleado por ID");
            System.out.println("4. Consultar empleados por proyecto");
            System.out.println("5. Registrar horas trabajadas");
            System.out.println("6. Actualizar empleado");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    registrarEmpleado();
                    break;
                case 2:
                    listarEmpleados();
                    break;
                case 3:
                    buscarEmpleadoPorId();
                    break;
                case 4:
                    consultarEmpleadosPorProyecto();
                    break;
                case 5:
                    registrarHorasTrabajadas();
                    break;
                case 6:
                    actualizarEmpleado();
                    break;
                case 0:
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }
    
    private static void registrarEmpleado() {
        System.out.println("\n===== REGISTRAR NUEVO EMPLEADO =====");
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        
        if (nombre.isEmpty()) {
            System.out.println("El nombre no puede estar vacío.");
            esperarEnter();
            return;
        }
        
        System.out.print("Cargo: ");
        String cargo = scanner.nextLine();
        
        System.out.print("Salario (COP): ");
        double salario = 0;
        try {
            salario = Double.parseDouble(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.out.println("Salario no válido. Se establecerá en 0.");
        }
        
        System.out.println("Especialidad (TI, Administracion, Limpieza, Seguridad): ");
        String especialidad = scanner.nextLine();
        
        System.out.print("ID del proyecto (dejar en blanco si no aplica): ");
        String idProyectoStr = scanner.nextLine();
        Integer idProyecto = null;
        
        if (!idProyectoStr.isEmpty()) {
            try {
                idProyecto = Integer.parseInt(idProyectoStr);
                
                Proyecto proyecto = proyectoDAO.buscarProyectoPorId(idProyecto);
                if (proyecto == null) {
                    System.out.println("No existe un proyecto con el ID: " + idProyecto);
                    System.out.println("El empleado se registrará sin asignar a un proyecto.");
                    idProyecto = null;
                }
            } catch (NumberFormatException e) {
                System.out.println("ID de proyecto no válido. El empleado se registrará sin asignar a un proyecto.");
            }
        }
        
        Empleado empleado = new Empleado(nombre, cargo, salario, especialidad, idProyecto);
        
        if (empleadoDAO.registrarEmpleado(empleado)) {
            System.out.println("Empleado registrado exitosamente.");
        } else {
            System.out.println("Error al registrar el empleado.");
        }
        
        esperarEnter();
    }
    
    private static void listarEmpleados() {
        System.out.println("\n===== LISTA DE EMPLEADOS =====");
        
        List<Empleado> empleados = empleadoDAO.listarEmpleados();
        
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados registrados.");
        } else {
            empleados.forEach(empleado -> {
                System.out.println("ID: " + empleado.getId());
                System.out.println("Nombre: " + empleado.getNombre());
                System.out.println("Cargo: " + empleado.getCargo());
                System.out.println("Salario: $" + empleado.getSalario() + " COP");
                System.out.println("Especialidad: " + empleado.getEspecialidad());
                System.out.println("ID Proyecto: " + (empleado.getIdProyecto() != null ? empleado.getIdProyecto() : "No asignado"));
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void buscarEmpleadoPorId() {
        System.out.println("\n===== BUSCAR EMPLEADO POR ID =====");
        
        System.out.print("Ingrese el ID del empleado: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Empleado empleado = empleadoDAO.buscarEmpleadoPorId(id);
        
        if (empleado == null) {
            System.out.println("No se encontró un empleado con el ID: " + id);
        } else {
            System.out.println("ID: " + empleado.getId());
            System.out.println("Nombre: " + empleado.getNombre());
            System.out.println("Cargo: " + empleado.getCargo());
            System.out.println("Salario: $" + empleado.getSalario() + " COP");
            System.out.println("Especialidad: " + empleado.getEspecialidad());
            System.out.println("ID Proyecto: " + (empleado.getIdProyecto() != null ? empleado.getIdProyecto() : "No asignado"));
            
            List<Asignacion> asignaciones = asignacionDAO.listarAsignacionesPorEmpleado(id);
            if (!asignaciones.isEmpty()) {
                System.out.println("\nAsignaciones:");
                asignaciones.forEach(asignacion -> {
                    System.out.println("Proyecto ID: " + asignacion.getIdProyecto());
                    System.out.println("Horas trabajadas: " + asignacion.getHorasTrabajadas());
                    System.out.println("Fecha de asignación: " + asignacion.getFechaAsignacion());
                    System.out.println("-----------------------------");
                });
            }
        }
        
        esperarEnter();
    }
    
    private static void consultarEmpleadosPorProyecto() {
        System.out.println("\n===== CONSULTAR EMPLEADOS POR PROYECTO =====");
        
        System.out.print("Ingrese el ID del proyecto: ");
        int idProyecto = leerOpcion();
        
        if (idProyecto <= 0) {
            System.out.println("ID de proyecto no válido.");
            esperarEnter();
            return;
        }
        
        Proyecto proyecto = proyectoDAO.buscarProyectoPorId(idProyecto);
        if (proyecto == null) {
            System.out.println("No existe un proyecto con el ID: " + idProyecto);
            esperarEnter();
            return;
        }
        
        List<Empleado> empleados = empleadoDAO.consultarEmpleadosPorProyecto(idProyecto);
        
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados asignados al proyecto: " + proyecto.getNombre());
        } else {
            System.out.println("\nEmpleados asignados al proyecto " + proyecto.getNombre() + ":");
            empleados.forEach(empleado -> {
                System.out.println("ID: " + empleado.getId());
                System.out.println("Nombre: " + empleado.getNombre());
                System.out.println("Cargo: " + empleado.getCargo());
                System.out.println("Especialidad: " + empleado.getEspecialidad());
                
                Asignacion asignacion = asignacionDAO.buscarAsignacion(empleado.getId(), idProyecto);
                if (asignacion != null) {
                    System.out.println("Horas trabajadas: " + asignacion.getHorasTrabajadas());
                }
                
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void registrarHorasTrabajadas() {
        System.out.println("\n===== REGISTRAR HORAS TRABAJADAS =====");
        
        System.out.print("ID del empleado: ");
        int idEmpleado = leerOpcion();
        
        if (idEmpleado <= 0) {
            System.out.println("ID de empleado no válido.");
            esperarEnter();
            return;
        }
        
        Empleado empleado = empleadoDAO.buscarEmpleadoPorId(idEmpleado);
        if (empleado == null) {
            System.out.println("No existe un empleado con el ID: " + idEmpleado);
            esperarEnter();
            return;
        }
        
        System.out.print("ID del proyecto: ");
        int idProyecto = leerOpcion();
        
        if (idProyecto <= 0) {
            System.out.println("ID de proyecto no válido.");
            esperarEnter();
            return;
        }
        
        Proyecto proyecto = proyectoDAO.buscarProyectoPorId(idProyecto);
        if (proyecto == null) {
            System.out.println("No existe un proyecto con el ID: " + idProyecto);
            esperarEnter();
            return;
        }
        
        Asignacion asignacion = asignacionDAO.buscarAsignacion(idEmpleado, idProyecto);
        if (asignacion == null) {
            System.out.println("El empleado no está asignado a este proyecto.");
            System.out.print("¿Desea crear una nueva asignación? (S/N): ");
            String respuesta = scanner.nextLine();
            
            if (respuesta.equalsIgnoreCase("S")) {
                asignacion = new Asignacion(idEmpleado, idProyecto, 0, LocalDate.now());
                if (!asignacionDAO.registrarAsignacion(asignacion)) {
                    System.out.println("Error al crear la asignación.");
                    esperarEnter();
                    return;
                }
            } else {
                esperarEnter();
                return;
            }
        }
        
        System.out.print("Horas adicionales trabajadas: ");
        double horasAdicionales = 0;
        try {
            horasAdicionales = Double.parseDouble(scanner.nextLine());
            if (horasAdicionales <= 0) {
                System.out.println("Las horas deben ser un valor positivo.");
                esperarEnter();
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("Valor no válido.");
            esperarEnter();
            return;
        }
        
        if (asignacionDAO.registrarHorasTrabajadas(idEmpleado, idProyecto, horasAdicionales)) {
            System.out.println("Horas registradas exitosamente.");
            empleado.registrarHorasTrabajadas(idProyecto, horasAdicionales);
        } else {
            System.out.println("Error al registrar las horas trabajadas.");
        }
        
        esperarEnter();
    }
    
    private static void actualizarEmpleado() {
        System.out.println("\n===== ACTUALIZAR EMPLEADO =====");
        
        System.out.print("Ingrese el ID del empleado a actualizar: ");
        int id = leerOpcion();
        
        if (id <= 0) {
            System.out.println("ID no válido.");
            esperarEnter();
            return;
        }
        
        Empleado empleado = empleadoDAO.buscarEmpleadoPorId(id);
        
        if (empleado == null) {
            System.out.println("No se encontró un empleado con el ID: " + id);
            esperarEnter();
            return;
        }
        
        System.out.println("Datos actuales del empleado:");
        System.out.println("Nombre: " + empleado.getNombre());
        System.out.println("Cargo: " + empleado.getCargo());
        System.out.println("Salario: $" + empleado.getSalario() + " COP");
        System.out.println("Especialidad: " + empleado.getEspecialidad());
        System.out.println("ID Proyecto: " + (empleado.getIdProyecto() != null ? empleado.getIdProyecto() : "No asignado"));
        
        System.out.println("\nIngrese los nuevos datos (deje en blanco para mantener el valor actual):");
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        if (!nombre.isEmpty()) {
            empleado.setNombre(nombre);
        }
        
        System.out.print("Cargo: ");
        String cargo = scanner.nextLine();
        if (!cargo.isEmpty()) {
            empleado.setCargo(cargo);
        }
        
        System.out.print("Salario (COP): ");
        String salarioStr = scanner.nextLine();
        if (!salarioStr.isEmpty()) {
            try {
                double salario = Double.parseDouble(salarioStr);
                empleado.setSalario(salario);
            } catch (NumberFormatException e) {
                System.out.println("Salario no válido. Se mantendrá el valor actual.");
            }
        }
        
        System.out.print("Especialidad (TI, Administracion, Limpieza, Seguridad): ");
        String especialidad = scanner.nextLine();
        if (!especialidad.isEmpty()) {
            empleado.setEspecialidad(especialidad);
        }
        
        System.out.print("ID del proyecto (dejar en blanco para mantener, 0 para desasignar): ");
        String idProyectoStr = scanner.nextLine();
        if (!idProyectoStr.isEmpty()) {
            try {
                int idProyecto = Integer.parseInt(idProyectoStr);
                if (idProyecto == 0) {
                    empleado.setIdProyecto(null);
                } else {
                    Proyecto proyecto = proyectoDAO.buscarProyectoPorId(idProyecto);
                    if (proyecto == null) {
                        System.out.println("No existe un proyecto con el ID: " + idProyecto);
                        System.out.println("Se mantendrá el valor actual.");
                    } else {
                        empleado.setIdProyecto(idProyecto);
                    }
                }
            } catch (NumberFormatException e) {
                System.out.println("ID de proyecto no válido. Se mantendrá el valor actual.");
            }
        }
        
        if (empleadoDAO.actualizarEmpleado(empleado)) {
            System.out.println("Empleado actualizado exitosamente.");
        } else {
            System.out.println("Error al actualizar el empleado.");
        }
        
        esperarEnter();
    }
    
    private static void generarInformes() {
        boolean volver = false;
        
        while (!volver) {
            System.out.println("\n===== INFORMES =====");
            System.out.println("1. Ver ingresos totales de contratos activos");
            System.out.println("2. Listar servicios más contratados");
            System.out.println("3. Listar empleados con más horas trabajadas");
            System.out.println("4. Ver resúmenes de contratos finalizados");
            System.out.println("0. Volver al menú principal");
            System.out.print("Seleccione una opción: ");
            
            int opcion = leerOpcion();
            
            switch (opcion) {
                case 1:
                    verIngresosTotales();
                    break;
                case 2:
                    listarServiciosMasContratados();
                    break;
                case 3:
                    listarEmpleadosConMasHorasTrabajadas();
                    break;
                case 4:
                    verResumenesContratos();
                    break;
                case 0:
                    volver = true;
                    break;
                default:
                    System.out.println("Opción no válida. Intente nuevamente.");
            }
        }
    }
    
    private static void verIngresosTotales() {
        System.out.println("\n===== INGRESOS TOTALES DE CONTRATOS ACTIVOS =====");
        
        double ingresos = contratoDAO.calcularIngresosTotales();
        
        System.out.println("Ingresos totales: $" + ingresos + " COP");
        
        esperarEnter();
    }
    
    private static void listarServiciosMasContratados() {
        System.out.println("\n===== SERVICIOS MÁS CONTRATADOS =====");
        
        System.out.print("Número de servicios a mostrar: ");
        int limite = 5;
        try {
            limite = Integer.parseInt(scanner.nextLine());
            if (limite <= 0) {
                System.out.println("Valor no válido. Se mostrará el top 5.");
                limite = 5;
            }
        } catch (NumberFormatException e) {
            System.out.println("Valor no válido. Se mostrará el top 5.");
        }
        
        List<Servicio> servicios = servicioDAO.listarServiciosMasContratados(limite);
        
        if (servicios.isEmpty()) {
            System.out.println("No hay servicios contratados.");
        } else {
            System.out.println("\nTop " + limite + " servicios más contratados:");
            int posicion = 1;
            for (Servicio servicio : servicios) {
                System.out.println(posicion + ". " + servicio.getNombre() + " - Categoría: " + servicio.getCategoria());
                posicion++;
            }
        }
        
        esperarEnter();
    }
    
    private static void listarEmpleadosConMasHorasTrabajadas() {
        System.out.println("\n===== EMPLEADOS CON MÁS HORAS TRABAJADAS =====");
        
        System.out.print("Número de empleados a mostrar: ");
        int limite = 5;
        try {
            limite = Integer.parseInt(scanner.nextLine());
            if (limite <= 0) {
                System.out.println("Valor no válido. Se mostrará el top 5.");
                limite = 5;
            }
        } catch (NumberFormatException e) {
            System.out.println("Valor no válido. Se mostrará el top 5.");
        }
        
        List<Empleado> empleados = empleadoDAO.listarEmpleadosConMasHorasTrabajadas(limite);
        
        if (empleados.isEmpty()) {
            System.out.println("No hay registros de horas trabajadas.");
        } else {
            System.out.println("\nTop " + limite + " empleados con más horas trabajadas:");
            int posicion = 1;
            for (Empleado empleado : empleados) {
                System.out.println(posicion + ". " + empleado.getNombre() + " - Cargo: " + empleado.getCargo());
                posicion++;
            }
        }
        
        esperarEnter();
    }
    
    private static void verResumenesContratos() {
        System.out.println("\n===== RESÚMENES DE CONTRATOS FINALIZADOS =====");
        
        List<String> resumenes = ArchivoUtil.leerResumenesContratos();
        
        if (resumenes.isEmpty()) {
            System.out.println("No hay resúmenes de contratos finalizados.");
        } else {
            resumenes.forEach(resumen -> {
                System.out.println(ArchivoUtil.formatearResumenContrato(resumen));
                System.out.println("-----------------------------");
            });
        }
        
        esperarEnter();
    }
    
    private static void esperarEnter() {
        System.out.println("\nPresione ENTER para continuar...");
        scanner.nextLine();
    }
}